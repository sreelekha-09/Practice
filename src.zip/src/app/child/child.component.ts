import { EventEmitter } from '@angular/core';
import { Component, Input, OnInit, Output } from '@angular/core';


@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
@Input() users;
@Output() emittedValue= new EventEmitter<boolean>();
  constructor() { }

  ngOnInit(): void {
  }
  hideUsers(value: boolean)
  {
    this.emittedValue.emit(value);
  }
}
