import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  users=[
    {name:'sree',id:1,status:'online'},
    {name:'bhavishya',id:2,status:'offline'},
    {name:'swetha',id:3,status:'online'}
  ];
  show=false;
  constructor() { }
  showUsers()
  {
    this.show=true;
  }
  hideUsers(value:boolean)
  {
    this.show=value;
  }
  getColor(status:string)
  {
    if(status==='online')
    {
      return 'skyblue';
    }
    else{
      return 'black'
    }
  }
  ngOnInit(): void {
  }

}
